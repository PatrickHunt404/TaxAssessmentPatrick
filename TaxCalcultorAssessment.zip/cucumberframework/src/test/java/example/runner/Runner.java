package example.runner;

import TaxCalculatorAssessment.LandingPage;
import TaxCalculatorAssessment.StatePensionPage;
import TaxCalculatorAssessment.TaxCodePage;
import TaxCalculatorAssessment.ScottishIncomeTaxPage;
import TaxCalculatorAssessment.PreResultsPage;
import org.junit.*;

import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Runner {

    private static WebDriver browser;


    @BeforeClass
    public static void createBrowser() {
        browser = new ChromeDriver();
    }

    @AfterClass
    public static void closeBrowser() {
        browser.quit();
    }

    private final LandingPage landingPage = new LandingPage(browser);
    private final StatePensionPage statePensionPage = new StatePensionPage((browser));
    private final TaxCodePage taxCodePage = new TaxCodePage((browser));
    private final ScottishIncomeTaxPage scottishIncomeTaxPage = new ScottishIncomeTaxPage(browser);
    private final PreResultsPage preResultsPage = new PreResultsPage(browser);
    @Before
    public void goLandingPage() {
        landingPage.navigateTo();
    }

    @Test
    public void testPageOpens(){

        Assert.assertEquals("How much do you get paid?",
                landingPage.getHeading());
    }

    @Test
    public void testNoInput(){
        landingPage.pressContinueButton();

        Assert.assertEquals("Something’s wrong\n" + "You haven’t entered how much you get paid\n" +
                        "You haven’t chosen how often you get paid",
                landingPage.getErrorMessage());
    }


    @Test
    public void happyPath0 (){
        landingPage.pressYearButton();
        landingPage.enterAmount("21500");
        landingPage.pressContinueButton();
        Assert.assertEquals("How many days a week do you usually work?", statePensionPage.getHeading());
        statePensionPage.enterDays("5");
        statePensionPage.pressContinueButton();
        Assert.assertEquals("Do you want to use your current tax code?",taxCodePage.getHeading());
        taxCodePage.statePensionNo();
        taxCodePage.pressContinueButton();
        Assert.assertEquals("Do you pay the Scottish Income Tax Rate?",scottishIncomeTaxPage.getHeading());
        scottishIncomeTaxPage.scottishRateNo();
        scottishIncomeTaxPage.pressContinueButton();
        Assert.assertEquals("Check your answers",preResultsPage.getHeading());
        preResultsPage.pressGetResultsButton();





    }



}