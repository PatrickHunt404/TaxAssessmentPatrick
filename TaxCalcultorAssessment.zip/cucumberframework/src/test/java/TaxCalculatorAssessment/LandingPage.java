package TaxCalculatorAssessment;

import example.utils.Driver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import java.util.concurrent.TimeUnit;

public class LandingPage extends Driver {

    public LandingPage (WebDriver driver) {
        super(driver);
    }


    public LandingPage navigateTo() {
        driver.navigate().to("https://www.tax.service.gov.uk/estimate-paye-take-home-pay/your-pay");
        return new LandingPage(driver);

    }


    public String getHeading() {
        return driver.findElement(By.tagName("h1")).getText();
    }

    public String getErrorMessage() {return driver.findElement(By.id("error-summary-display")).getText();}

    public void pressContinueButton() {
        driver.findElement(By.id("p-continue")).click();
        driver.manage().timeouts().implicitlyWait( 3, TimeUnit.SECONDS);
    }

    public void pressHourButton (){
        driver.findElement(By.cssSelector("#hourly")).click();
    }

    public void pressDayButton (){
        driver.findElement(By.cssSelector("#daily")).click();
    }

    public void pressMonthButton (){
        driver.findElement(By.cssSelector("#monthly")).click();
    }

    public void pressYearButton () {
        driver.findElement(By.cssSelector("#yearly")).click();
    }

    public void enterAmount (String amount){
        driver.findElement(By.cssSelector("#pay-amount")).sendKeys(amount);

    }

}
