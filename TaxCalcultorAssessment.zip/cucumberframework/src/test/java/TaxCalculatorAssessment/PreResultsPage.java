package TaxCalculatorAssessment;

import example.utils.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.concurrent.TimeUnit;

public class PreResultsPage extends Driver {

    public PreResultsPage(WebDriver driver) {
        super(driver);
    }


    public PreResultsPage navigateTo() {
        driver.navigate().to("https://www.tax.service.gov.uk/estimate-paye-take-home-pay/your-pay");
        return new PreResultsPage(driver);

    }


    public String getHeading() {
        return driver.findElement(By.tagName("h1")).getText();
    }

    public String getErrorMessage() {return driver.findElement(By.id("error-summary-display")).getText();}

    public void pressGetResultsButton() {
        driver.findElement(By.id("get-results")).click();
        driver.manage().timeouts().implicitlyWait( 3, TimeUnit.SECONDS);
    }


    }


