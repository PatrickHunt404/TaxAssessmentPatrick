package TaxCalculatorAssessment;

import example.utils.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.concurrent.TimeUnit;


public class ScottishIncomeTaxPage extends Driver {

    public ScottishIncomeTaxPage(WebDriver driver) {
        super(driver);
    }

    public ScottishIncomeTaxPage navigateTo() {
        driver.navigate().to("https://www.tax.service.gov.uk/estimate-paye-take-home-pay/state-pension");
        return new ScottishIncomeTaxPage(driver);
    }

    public String getHeading() {
        return driver.findElement(By.tagName("h1")).getText();
    }

    public void scottishRateNo() {
        driver.findElement(By.id("scottish-rate-no")).click();
    }

    public void scottishRateYes() {
        driver.findElement(By.id("scottish-rate-yes")).click();
    }

    public void pressContinueButton() {
        driver.findElement(By.id("sr-continue")).click();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

    }
}


