package TaxCalculatorAssessment;

import example.utils.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.concurrent.TimeUnit;


public class TaxCodePage extends Driver {

    public TaxCodePage(WebDriver driver) {
        super(driver);
    }

    public TaxCodePage navigateTo() {
        driver.navigate().to("https://www.tax.service.gov.uk/estimate-paye-take-home-pay/state-pension");
        return new TaxCodePage(driver);
    }

    public String getHeading() {
        return driver.findElement(By.tagName("h1")).getText();
    }

    public void statePensionYes() {
        driver.findElement(By.id("over-state-pension-age-yes")).click();
    }

    public void statePensionNo() {
        driver.findElement(By.id("over-state-pension-age-no")).click();
    }

    public void pressContinueButton() {
        driver.findElement(By.id("sp-continue")).click();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

    }
}


