package TaxCalculatorAssessment;

import example.utils.Driver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import java.util.concurrent.TimeUnit;


public class StatePensionPage extends Driver {

    public StatePensionPage(WebDriver driver) {
        super(driver);
    }

    public StatePensionPage navigateTo() {
        driver.navigate().to("https://www.tax.service.gov.uk/estimate-paye-take-home-pay/days/5000?url=%2Festimate-paye-take-home-pay%2Fyour-pay");
        return new StatePensionPage(driver);
    }

    public String getHeading() {
        return driver.findElement(By.tagName("h1")).getText();
    }

    public void enterDays(String days) {
        driver.findElement(By.cssSelector("#how-many-days-a-week")).sendKeys(days);
    }

    public void pressContinueButton() {
        driver.findElement(By.id("pd-continue")).click();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

    }
}



